require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const path = require('path');

const app = express();

// Render sits behind a proxy; without this every visitor looks like the same
// IP, which would make per-IP rate limiting punish everyone for one person.
app.set('trust proxy', 1);

// ── MIDDLEWARE ─────────────────────────────────────
app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({
  origin: [
    'https://wealthguard-rho.vercel.app',
    'http://localhost:3000',
    'http://localhost:5500',
    process.env.FRONTEND_URL,
  ].filter(Boolean),
  credentials: true,
  methods: ['GET','POST','PUT','DELETE','OPTIONS'],
  allowedHeaders: ['Content-Type','Authorization'],
}));
// NOTE: no separate app.options('*', cors()) here — the cors() middleware
// above already handles OPTIONS preflight automatically for every route.
// The explicit wildcard version was not only redundant, it's what crashed
// the whole server: newer path-to-regexp (pulled in by Node 24) dropped
// support for the bare '*' pattern and throws instead of matching it.
// 100 KB is far more than any request here needs (the old 10 MB limit applied
// to unauthenticated routes too).
app.use(express.json({ limit: '100kb' }));
app.use(express.urlencoded({ extended: true, limit: '100kb' }));

// ── STATIC FRONTEND ───────────────────────────────
app.use(express.static(path.join(__dirname, '../frontend/public')));

// ── API ROUTES ────────────────────────────────────
app.use('/api/auth',         require('./routes/auth'));
app.use('/api/clients',      require('./routes/clients'));
app.use('/api/portfolio',    require('./routes/portfolio'));
app.use('/api/signals',      require('./routes/signals'));
app.use('/api/market',       require('./routes/market'));
app.use('/api/brief',        require('./routes/brief'));
app.use('/api/goals',        require('./routes/goals'));
app.use('/api/whatsapp',     require('./routes/whatsapp'));
app.use('/api/payments',     require('./routes/payments'));
app.use('/api/admin',        require('./routes/admin'));

// ── FRONTEND SPA fallback ─────────────────────────
// Uses app.use() with no path pattern at all, instead of app.get('*', ...).
// A bare '*' string has to be parsed as a route pattern by path-to-regexp,
// which is exactly what crashed above — app.use() with no path never goes
// through that parser, so this form is safe under any router version.
app.use((req, res) => {
  // An /api path that matched no route must 404. This handler used to do
  // NOTHING in that case — no response, no next() — so the socket stayed open
  // until the caller timed out. A single missing route therefore looked like a
  // dead server, and any future typo in an API path would do the same.
  if (req.path.startsWith('/api')) {
    console.warn(`   ⚠ 404 — no route for ${req.method} ${req.path}`);
    return res.status(404).json({
      error: `No such endpoint: ${req.method} ${req.path}`,
      hint: 'Check the path against backend/routes/. A mismatch here used to hang the request.',
    });
  }
  res.sendFile(path.join(__dirname, '../frontend/public/index.html'));
});

// ── ERROR HANDLER ─────────────────────────────────
app.use((err, req, res, next) => {
  console.error(err.stack);
  const status = err.status || 500;
  const dev = process.env.NODE_ENV === 'development';
  res.status(status).json({
    // Raw error text can name tables, columns and constraints. Only 4xx messages
    // (which are about the request itself) go out; 5xx are generic.
    error: dev || (status < 500 && err.expose !== false) ? (err.message || 'Request error') : 'Something went wrong. Please try again.',
    ...(dev && { stack: err.stack })
  });
});

// ── SCHEDULERS ────────────────────────────────────
const { startSchedulers } = require('./services/scheduler');
if (process.env.NODE_ENV !== 'test') startSchedulers();

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`\n🛡️  WealthGuard Platform v1.0`);
  console.log(`   Server running on http://localhost:${PORT}`);
  console.log(`   Environment: ${process.env.NODE_ENV || 'development'}\n`);
});

module.exports = app;
